<style type="text/css">
.span{
    font-size:15px;
}

.text{
    margin:20px 0px;
}

.fa{
     color:#4183D7;
}
</style>


<div class="box">
    <div class="container">
     	<div class="row">

		 <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
               
			   <div class="box-part text-center">
				   
				   <i class="fa fa-envelope fa-3x" aria-hidden="true"></i>
				   
				   <div class="title">
					   <h4>Chat online</h4>
				   </div>
				   
				   <div class="text">
					   <span class="span">Os melhores atendentes prontos para te ajudar e lhe trazer o melhor.</span>
				   </div>
				   
				   <a href="home.php" class="btn btn-primary">Clique Aqui</a>
				   
				</div>
		   </div>	 
		   
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
		  
			   <div class="box-part text-center">
				   
				   <i class="fa fa-phone fa-3x" aria-hidden="true"></i>
			   
				   <div class="title">
					   <h4>SAC</h4>
				   </div>
				   
				   <div class="text">
					   <span class="span">Ligue para ser atendido a qualquer horário e a qualquer dia.</span>
				   </div>
				   
				   <a href="tel:143263-4658" class="btn btn-primary">Ligue Agora</a>
				   
				</div>
		   </div>	 
		   
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
		  
			   <div class="box-part text-center">
				   
				   <i class="fa fa-user fa-3x" aria-hidden="true"></i>
				   
				   <div class="title">
					   <h4>Trabalhe conosco</h4>
				   </div>
				   
				   <div class="text">
					   <span class="span">Cadastre seu curriculo na nossa central de empregos.</span>
				   </div>
				   
				   <a href="trabalhe_conosco.php" class="btn btn-primary">Trabalhe Conosco</a>
				   
				</div>
		   </div>	 
		   

		</div>		
    </div>
</div>

