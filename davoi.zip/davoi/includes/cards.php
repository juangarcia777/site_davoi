 <style type="text/css">
 i#icon {
    margin-top: 25px;
}
@media screen and (max-width:400px) {
  i#icon {
    margin-top: 25px;
}
}
 
 </style>
 
 <!-- Services -->
    <section class="power-hosting padding-top-100 padding-bottom-100">
      <div class="container"> 
        
        <!-- Tittle -->
        <div class="heading">
          <h2>DAVOI É MUITO MAIS INTERNET.</h2>
        </div>
        <ul class="row">
            <!-- 24/7 support -->
          <li class="col-md-3">
            <div class="icon"> <i id="icon" class="fa fa-volume-control-phone"></i> </div>
            <h5>Atendimento 24/7</h5>
            <p>O melhor Atendimento sempre a sua disposição 24 horas por dia par sua melhor comodidade, contando sempre com profissionais treinados e experientes.</p>
            <a href="all_contact.php" class="btn">Saiba Mais <i class="fa fa-long-arrow-right"></i></a> </li>
          
          <!-- Pro-Team -->
          <li class="col-md-3">
            <div class="icon"> <i id="icon" class="fa fa-users"></i> </div>
            <h5>Suporte técnico</h5>
            <p>Os melhores profissionais treinados e com experiênçia para te ajudar na solução dos mais diversificados problemas.</p>
            <a href="all_contact.php" class="btn">Saiba Mais <i class="fa fa-long-arrow-right"></i></a> </li>
          
          <!-- Happy Customers -->
          <li class="col-md-3">
            <div class="icon"> <i id="icon" class="fa fa-heart-o"></i> </div>
            <h5>Clientes Satisfeitos</h5>
            <p>Nossa grande gama de clientes varia desde residênçias até estabelecimentos comercias sempre levando um trabalho com excelência.</p>
            <a href="planos_internet.php" class="btn">Saiba Mais <i class="fa fa-long-arrow-right"></i></a> </li>
          
          <!-- Best Prices -->
          <li class="col-md-3">
            <div class="icon"> <i id="icon" class="fa fa-money"></i> </div>
            <h5>Melhores Preços</h5>
            <p>Nossos preços são sempre acessíveis para caber no bolso de nossos clientes, sempre levando o melhor plano pelo melhor preço da região.</p>
            <a href="planos_internet.php" class="btn">Saiba Mais <i class="fa fa-long-arrow-right"></i></a> </li>
         
        </ul>
      </div>
    </section>