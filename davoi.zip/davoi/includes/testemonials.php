<!-- Choose Services -->
    <section class="testimonial padding-top-150 padding-bottom-150">
      <div class="container"> 
        
        <!-- Tittle -->
        <div class="heading">
          <h2>hear what they say <small>testimonials</small></h2>
        </div>
        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel"> 
          
          <!-- Wrapper for slides -->
          <div class="carousel-inner" role="listbox"> 
            
            <!-- Slides 1 -->
            <div class="item active">
              <p>There are design companies, and then there are user experience, design, consulting, interface design, brilliant, and professional. UOU Apps, is by far one of the worlds best known brands.</p>
            </div>
            
            <!-- Slides 2 -->
            <div class="item">
              <p>There are design companies, and then there are user experience, design, consulting, interface design, brilliant, and professional. UOU Apps, is by far one of the worlds best known brands.</p>
            </div>
            
            <!-- Slides 3 -->
            <div class="item">
              <p>There are design companies, and then there are user experience, design, consulting, interface design, brilliant, and professional. UOU Apps, is by far one of the worlds best known brands.</p>
            </div>
          </div>
          
          <!-- Indicators -->
          <ol class="carousel-indicators">
            
            <!-- THUMB 1 -->
            <li data-target="#carousel-example-generic" data-slide-to="0" class="active">
              <div class="media-left"> <img src="images/testi-avatar.jpg" alt=""> </div>
              <div class="media-body">
                <h6>John Kevin Mara</h6>
                <span>smashingmagazine.com</span> </div>
            </li>
            
            <!-- THUMB 2 -->
            
            <li data-target="#carousel-example-generic" data-slide-to="1">
              <div class="media-left"> <img src="images/testi-avatar.jpg" alt=""> </div>
              <div class="media-body ">
                <h6>John Kevin Mara</h6>
                <span>smashingmagazine.com</span> </div>
            </li>
            
            <!-- THUMB 3 -->
            
            <li data-target="#carousel-example-generic" data-slide-to="2">
              <div class="media-left"> <img src="images/testi-avatar.jpg" alt=""> </div>
              <div class="media-body ">
                <h6>John Kevin Mara</h6>
                <span>smashingmagazine.com</span> </div>
            </li>
          </ol>
        </div>
      </div>
    </section>