<style type="text/css">
.span{
    font-size:15px;
}
.box{
    padding:60px 0px;
}

.box-part1{
    background:#c8ced2;
    border-radius:0;
    padding:60px 10px;
    margin:30px 0px;
    margin-top:0;
}
.text{
    margin:20px 0px;
}

.fa{
     color:#4183D7;
}
</style>


<div class="box" id="emails">
    <div class="container">
     	<div class="row">
			 
			    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
               
					<div class="box-part1 text-center">
                        
                        <i class="fa fa-cogs fa-3x" aria-hidden="true"></i>
                        
						<div class="title">
							<h4>Suporte técnico</h4>
						</div>
                        
						<div class="text">
							<span class="span">suporte@davoi.com.br</span>
						</div>
                                                
					 </div>
				</div>	 
				
				 <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
               
					<div class="box-part1 text-center">
					    
					    <i class="fa fa-credit-card fa-3x" aria-hidden="true"></i>
                    
						<div class="title">
							<h4>Financeiro</h4>
						</div>
                        
						<div class="text">
							<span class="span">financeiro@davoi.com.br</span>
						</div>
                                                
					 </div>
				</div>	 
				
				 <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
               
					<div class="box-part1 text-center">
                        
                        <i class="fa fa-child fa-3x" aria-hidden="true"></i>
                        
						<div class="title">
							<h4>Comercial</h4>
						</div>
                        
						<div class="text">
							<span class="span">comercial@davoi.com.br</span>
						</div>
                                                
					 </div>
				</div>	 
				
				
				
		
		</div>		
    </div>
</div>

