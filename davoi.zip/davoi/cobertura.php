
<meta name="viewport" content="width=device-width, initial-scale=1,shrink-to-fit=no">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!-- Include the above in your HEAD tag -->

<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="css/aux_cobertura.css">



<div class="main">
    
    <div class="container">
<center>
<div class="middle">
      <div id="login">

        <form action="" method="GET">

          <fieldset class="clearfix">

            <p ><span class="fa fa-building"></span>
               <select class="form-control" id="validationDefault04" required>
               
              </select>
            </p> <!-- JS because of IE support; better: placeholder="Username" -->
            <p style="padding-top:10px;"><span class="fa fa-filter"></span>
            <input type="text"  Placeholder="CEP" required></p> <!-- JS because of IE support; better: placeholder="Password" -->
            
             <div>                
                <span style="width:100%; text-align:right;  display: inline-block;">
                <input type="submit" value="Avançar"></span>
              </div>

          </fieldset>
<div class="clearfix"></div>
        </form>

        <div class="clearfix"></div>

      </div> <!-- end login -->
      <div class="logo">
          <img src="images/logo-davoi (2).png">
          <div class="clearfix"></div>
      </div>
      
      </div>
</center>
    </div>

</div>