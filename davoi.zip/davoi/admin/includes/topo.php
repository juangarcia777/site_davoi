<?php include("../class/class.db.php"); ?>
<?php include("class/class.seguranca.php"); ?>
<?php include("class/class.session_ativa.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>ÁREA ADMINISTRATIVA | MEGA DESIGN</title>

<link rel="stylesheet" href="css/bootstrap.css" >
<link rel="shortcut icon" href="../assets/favicon.ico">

<!-- The main CSS file -->
<link href="assets/css/style.css" rel="stylesheet" />

<script src='jquery/jquery.min.js'></script>
<script src='jquery/funcoes.js'></script>
<script src='jquery/jquery.maskMoney.js'></script>
<script src='jquery/mascara.js'></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script src="https://use.fontawesome.com/e93073f887.js"></script>


<link href="css/upload.css" rel="stylesheet">
<script src="jquery/up.js"></script>


</head>

<body>


<?php include("includes/menu.php"); ?>


<div class="container-fluid">

	
    
		<div class="col-md-12" id="conteudo_geral">