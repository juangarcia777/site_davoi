<?php require 'includes/topo.php'; ?>
<?php require 'includes/menu.php'; ?>
<?php require 'includes/banner.php'; ?>
<?php require 'includes/plans.php'; ?>
<?php require 'includes/banner2.php'; ?>
<br/>

<?php require 'includes/cards.php'; ?>
<?php require 'includes/footer.php'; ?>
<?php require 'includes/aux_search.php'; ?>
